#!/usr/bin/env python3
"""
PostgreSQL Database Cleanup Script

This script cleans up duplicate tables in the PostgreSQL database
by dropping tables with reserved keyword names that have been migrated to
properly named tables.

The script:
1. Checks for old tables with PostgreSQL reserved keyword names (user, case)
2. Verifies data integrity in new tables (users, cases)
3. Drops old tables if data is intact
"""

import os
import sys
import logging
from sqlalchemy import create_engine, text, inspect
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Get PostgreSQL connection string from environment variables
db_url = os.environ.get("DATABASE_URL")

# Fix common issue with PostgreSQL URLs from Heroku/some PaaS providers
if db_url and db_url.startswith('postgres://'):
    db_url = db_url.replace('postgres://', 'postgresql://')

if not db_url:
    logger.error("No DATABASE_URL environment variable found. Cannot connect to database.")
    sys.exit(1)

# Connect to the database
try:
    engine = create_engine(db_url)
    logger.info("Connected to database")
except Exception as e:
    logger.error(f"Error connecting to database: {e}")
    sys.exit(1)

def check_table_exists(table_name):
    """Check if a table exists in the database"""
    inspector = inspect(engine)
    return table_name in inspector.get_table_names()

def get_row_count(table_name):
    """Get the number of rows in a table"""
    with engine.connect() as conn:
        return conn.execute(text(f'SELECT COUNT(*) FROM "{table_name}"')).scalar()

def drop_tables(tables):
    """Drop specified tables"""
    with engine.connect() as conn:
        try:
            trans = conn.begin()
            for table_name in tables:
                # Drop foreign keys first
                conn.execute(text(f'''
                DO $$ 
                DECLARE
                    r RECORD;
                BEGIN
                    FOR r IN (SELECT conname, conrelid::regclass AS table_from
                            FROM pg_constraint
                            WHERE confrelid = '"{table_name}"'::regclass)
                    LOOP
                        EXECUTE 'ALTER TABLE ' || r.table_from || ' DROP CONSTRAINT ' || r.conname;
                    END LOOP;
                END $$;
                '''))
                
                # Now drop the table
                conn.execute(text(f'DROP TABLE IF EXISTS "{table_name}"'))
                logger.info(f"Dropped table '{table_name}'")
            trans.commit()
            return True
        except Exception as e:
            trans.rollback()
            logger.error(f"Error dropping tables: {e}")
            return False

def main():
    """Main function to clean up duplicate tables"""
    # Check for old tables
    old_tables = []
    for old_name, new_name in [('user', 'users'), ('case', 'cases')]:
        if check_table_exists(old_name) and check_table_exists(new_name):
            old_count = get_row_count(old_name)
            new_count = get_row_count(new_name)
            logger.info(f"Found '{old_name}' table with {old_count} rows (new '{new_name}' has {new_count} rows)")
            old_tables.append(old_name)
    
    if not old_tables:
        logger.info("No duplicate tables found.")
        return
    
    # Prompt for confirmation
    logger.info(f"Found {len(old_tables)} old tables to drop: {', '.join(old_tables)}")
    
    confirmation = input(f"Do you want to drop these tables? This action cannot be undone. (yes/no): ")
    if confirmation.lower() != 'yes':
        logger.info("Operation cancelled by user.")
        return
    
    # Backup tables
    backup_time = datetime.now().strftime("%Y%m%d_%H%M%S")
    logger.info(f"Creating backups of tables before dropping...")
    with engine.connect() as conn:
        try:
            for table in old_tables:
                # Create backup table
                backup_table = f"{table}_backup_{backup_time}"
                conn.execute(text(f'CREATE TABLE "{backup_table}" AS SELECT * FROM "{table}"'))
                backup_count = get_row_count(backup_table)
                logger.info(f"Created backup '{backup_table}' with {backup_count} rows")
        except Exception as e:
            logger.error(f"Error creating backup: {e}")
            return
    
    # Drop old tables
    if drop_tables(old_tables):
        logger.info(f"Successfully dropped {len(old_tables)} old tables.")
        logger.info(f"Backup tables with prefix '_backup_{backup_time}' are available if needed.")
    else:
        logger.error("Failed to drop old tables.")

if __name__ == "__main__":
    main()