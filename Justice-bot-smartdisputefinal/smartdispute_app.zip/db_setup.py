#!/usr/bin/env python3
"""
Database Setup Script for SmartDispute.ai

This script:
1. Drops all existing tables (if any)
2. Creates new tables based on the models
3. Populates the database with sample data

WARNING: This script will DELETE ALL EXISTING DATA in the specified database.
"""

import os
import sys
import logging
import uuid
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import text
import json

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Create a minimal Flask app for the migration
app = Flask(__name__)

# Configure the database connection
db_url = os.environ.get("DATABASE_URL")
if db_url and db_url.startswith('postgres://'):
    db_url = db_url.replace('postgres://', 'postgresql://')

app.config["SQLALCHEMY_DATABASE_URI"] = db_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize SQLAlchemy
db = SQLAlchemy(app)

def drop_all_tables():
    """Drop all existing tables"""
    try:
        with db.engine.connect() as conn:
            conn = conn.execution_options(isolation_level="AUTOCOMMIT")
            inspector = db.inspect(db.engine)
            
            # Get all table names
            table_names = inspector.get_table_names()
            logger.info(f"Found {len(table_names)} tables: {', '.join(table_names)}")
            
            if not table_names:
                logger.info("No tables to drop")
                return True
            
            # Drop tables with foreign key constraints first
            logger.info("Dropping tables...")
            
            # Drop foreign keys
            conn.execute(text("""
            DO $$ 
            DECLARE
                r RECORD;
            BEGIN
                FOR r IN (SELECT conname, conrelid::regclass AS table_from
                        FROM pg_constraint
                        WHERE contype = 'f')
                LOOP
                    EXECUTE 'ALTER TABLE ' || r.table_from || ' DROP CONSTRAINT ' || r.conname;
                END LOOP;
            END $$;
            """))
            
            # Drop tables
            for table in table_names:
                conn.execute(text(f'DROP TABLE IF EXISTS "{table}" CASCADE'))
                logger.info(f"Dropped table: {table}")
            
            logger.info("All tables dropped successfully")
            return True
            
    except Exception as e:
        logger.error(f"Error dropping tables: {e}")
        return False

def create_tables():
    """Create all tables based on models"""
    try:
        # Import models when needed to avoid circular imports
        with app.app_context():
            # Import models to register them with SQLAlchemy
            import models
            
            logger.info("Creating tables...")
            db.create_all()
            logger.info("All tables created successfully")
            return True
            
    except Exception as e:
        logger.error(f"Error creating tables: {e}")
        return False

def populate_sample_data():
    """Populate the database with sample data"""
    try:
        with app.app_context():
            # Import models when needed
            from models import User, Dispute, Document, Payment, CaseMeritScore, ChatSession, ChatMessage
            
            logger.info("Populating tables with sample data...")
            
            # Create sample users
            user1 = User(
                full_name='Jane Doe',
                email='jane@example.com',
                password_hash=generate_password_hash('password123'),
                role='user',
                last_login=datetime.now()
            )
            
            user2 = User(
                full_name='Admin User',
                email='admin@example.com',
                password_hash=generate_password_hash('admin123'),
                role='admin',
                last_login=datetime.now() - timedelta(days=2)
            )
            
            db.session.add(user1)
            db.session.add(user2)
            db.session.commit()
            logger.info(f"Created users: {user1.full_name}, {user2.full_name}")
            
            # Create sample disputes
            dispute1 = Dispute(
                user_id=user1.id,
                case_type='Housing',
                status='draft',
                title='Apartment Ceiling Leak'
            )
            
            dispute2 = Dispute(
                user_id=user1.id,
                case_type='Credit Dispute',
                status='submitted',
                title='Wrong Collections Account'
            )
            
            db.session.add(dispute1)
            db.session.add(dispute2)
            db.session.commit()
            logger.info(f"Created disputes: {dispute1.title}, {dispute2.title}")
            
            # Create sample documents
            document1 = Document(
                dispute_id=dispute1.id,
                file_name='leak_photos.zip',
                file_url='/uploads/leak_photos.zip',
                file_type='upload',
                extracted_text='Photos showing water damage from ceiling leak in apartment.',
                doc_metadata={
                    'page_count': 3,
                    'size_kb': 1250,
                    'upload_date': datetime.now().isoformat()
                }
            )
            
            document2 = Document(
                dispute_id=dispute2.id,
                file_name='credit_dispute_letter.docx',
                file_url='/generated/credit_dispute_letter.docx',
                file_type='generated_form',
                extracted_text='Formal dispute letter for Equifax regarding incorrect collections account.',
                doc_metadata={
                    'page_count': 2,
                    'size_kb': 124,
                    'generated_date': datetime.now().isoformat()
                }
            )
            
            db.session.add(document1)
            db.session.add(document2)
            db.session.commit()
            logger.info(f"Created documents: {document1.file_name}, {document2.file_name}")
            
            # Create sample payment
            payment = Payment(
                user_id=user1.id,
                payment_provider='PayPal',
                payment_id='PAY-1234567890',
                amount=5.99,
                currency='CAD',
                status='completed',
                payment_type='document',
                service_details={
                    'document_id': str(document2.id),
                    'payment_date': datetime.now().isoformat(),
                    'service_type': 'document_generation'
                }
            )
            
            db.session.add(payment)
            db.session.commit()
            logger.info(f"Created payment record: {payment.payment_id}")
            
            # Create case merit score
            merit_score = CaseMeritScore(
                dispute_id=dispute2.id,
                score=85,
                summary='Strong case based on violation of FCRA reporting rules.',
                legal_references='Refer to FCRA 609(b) - right to dispute inaccuracies.',
                details={
                    'strengths': [
                        'Clear documentation of error',
                        'Multiple attempts to contact creditor',
                        'Statutory protections apply'
                    ],
                    'weaknesses': [
                        'Delayed response to initial notice'
                    ],
                    'relevant_cases': [
                        'Smith v. Experian (2020)',
                        'Jones v. TransUnion (2019)'
                    ]
                }
            )
            
            db.session.add(merit_score)
            db.session.commit()
            logger.info(f"Created case merit score for dispute: {dispute2.title}")
            
            # Create sample chat sessions and messages
            chat_session = ChatSession(
                user_id=user1.id,
                dispute_id=dispute1.id,
                title='Housing Dispute Assistance',
                session_data={
                    'opened_from': 'dispute_page',
                    'related_docs': [str(document1.id)]
                }
            )
            
            db.session.add(chat_session)
            db.session.commit()
            
            message1 = ChatMessage(
                session_id=chat_session.id,
                is_user=True,
                message='I have a water leak in my apartment ceiling. What rights do I have?'
            )
            
            message2 = ChatMessage(
                session_id=chat_session.id,
                is_user=False,
                message='In Ontario, your landlord is responsible for maintaining your unit in a good state of repair. This includes fixing leaks and water damage. You should notify your landlord in writing about the issue and keep a copy for your records. If the landlord fails to fix the issue within a reasonable time, you can file a T6 maintenance application with the Landlord and Tenant Board.',
                message_data={
                    'references': [
                        'Residential Tenancies Act, 2006, S.O. 2006, c. 17, s. 20',
                        'Ontario Landlord and Tenant Board Form T6'
                    ],
                    'analysis': 'Clear case of landlord responsibility for unit maintenance'
                }
            )
            
            db.session.add(message1)
            db.session.add(message2)
            db.session.commit()
            logger.info(f"Created chat session with {2} messages")
            
            logger.info("Sample data populated successfully")
            return True
            
    except Exception as e:
        logger.error(f"Error populating sample data: {e}")
        return False

def setup_database():
    """Set up the complete database"""
    logger.info("=== Starting Database Setup ===")
    
    # Ask for confirmation
    if input("This will DELETE ALL EXISTING DATA in the database. Are you sure you want to continue? (yes/no): ").lower() != 'yes':
        logger.info("Operation cancelled by user")
        return
    
    # Step 1: Drop all existing tables
    if not drop_all_tables():
        logger.error("Failed to drop tables, aborting")
        return
    
    # Step 2: Create new tables
    if not create_tables():
        logger.error("Failed to create tables, aborting")
        return
    
    # Step 3: Populate with sample data
    if not populate_sample_data():
        logger.error("Failed to populate sample data")
        # Continue anyway as the tables are created
    
    logger.info("=== Database Setup Completed ===")

if __name__ == "__main__":
    setup_database()