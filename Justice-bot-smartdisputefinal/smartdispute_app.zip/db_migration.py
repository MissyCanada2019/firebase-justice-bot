import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import text
from datetime import datetime
import uuid

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Create a minimal Flask app for the migration
app = Flask(__name__)

# Configure the database connection
db_url = os.environ.get("DATABASE_URL")
if db_url and db_url.startswith('postgres://'):
    db_url = db_url.replace('postgres://', 'postgresql://')

app.config["SQLALCHEMY_DATABASE_URI"] = db_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize SQLAlchemy
db = SQLAlchemy(app)

def check_table_exists(table_name):
    """Check if a table exists in the database"""
    with db.engine.connect() as connection:
        result = connection.execute(text(
            f"SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = '{table_name}')"
        ))
        return result.scalar()

def migrate_users():
    """Migrate data from 'user' table to 'users' table"""
    if not check_table_exists('user'):
        logger.info("Old 'user' table doesn't exist, skipping user migration")
        return
    
    if not check_table_exists('users'):
        logger.info("New 'users' table doesn't exist, you need to run app first to create it")
        return
    
    # Check if there's data to migrate
    with db.engine.connect() as connection:
        # Disable autocommit to manage our own transactions
        connection = connection.execution_options(isolation_level="AUTOCOMMIT")
        
        # Count records in old table
        old_count = connection.execute(text("SELECT COUNT(*) FROM \"user\"")).scalar()
        if old_count == 0:
            logger.info("No data in old 'user' table to migrate")
            return
        
        # Count records in new table
        new_count = connection.execute(text("SELECT COUNT(*) FROM users")).scalar()
        
        logger.info(f"Found {old_count} records in old 'user' table and {new_count} in new 'users' table")
        
        # Get existing emails in new table
        existing_emails = [row[0] for row in connection.execute(text("SELECT email FROM users")).fetchall()]
        
        # Get old records
        old_users = connection.execute(text("SELECT * FROM \"user\"")).fetchall()
        
        try:
            # Use separate transaction per user for safety
            migrated_count = 0
            for user in old_users:
                # Skip if email already exists in new table
                if user.email in existing_emails:
                    logger.info(f"User with email {user.email} already exists in new table, skipping")
                    continue
                
                # Insert into new table
                query = text("""
                INSERT INTO users (username, email, password_hash, created_at, subscription_type, subscription_end, uuid) 
                VALUES (:username, :email, :password_hash, :created_at, :subscription_type, :subscription_end, :uuid)
                """)
                
                with connection.begin():
                    connection.execute(query, {
                        'username': user.username,
                        'email': user.email,
                        'password_hash': user.password_hash,
                        'created_at': user.created_at,
                        'subscription_type': user.subscription_type,
                        'subscription_end': user.subscription_end,
                        'uuid': uuid.uuid4()
                    })
                    migrated_count += 1
            
            logger.info(f"Successfully migrated {migrated_count} users from 'user' to 'users'")
            
        except Exception as e:
            logger.error(f"Error migrating users: {str(e)}")
            raise

def migrate_cases():
    """Migrate data from 'case' table to 'cases' table"""
    if not check_table_exists('case'):
        logger.info("Old 'case' table doesn't exist, skipping case migration")
        return
    
    if not check_table_exists('cases'):
        logger.info("New 'cases' table doesn't exist, you need to run app first to create it")
        return
    
    # Check if there's data to migrate
    with db.engine.connect() as connection:
        # Count records in old table
        old_count = connection.execute(text("SELECT COUNT(*) FROM \"case\"")).scalar()
        if old_count == 0:
            logger.info("No data in old 'case' table to migrate")
            return
        
        # Count records in new table
        new_count = connection.execute(text("SELECT COUNT(*) FROM cases")).scalar()
        
        logger.info(f"Found {old_count} records in old 'case' table and {new_count} in new 'cases' table")
        
        # Get old records
        old_cases = connection.execute(text("SELECT * FROM \"case\"")).fetchall()
        
        # Begin transaction
        trans = connection.begin()
        try:
            migrated_count = 0
            for case in old_cases:
                # Check if case already exists
                existing = connection.execute(
                    text("SELECT id FROM cases WHERE user_id = :user_id AND title = :title AND created_at = :created_at"),
                    {'user_id': case.user_id, 'title': case.title, 'created_at': case.created_at}
                ).fetchone()
                
                if existing:
                    logger.info(f"Case with user_id={case.user_id}, title={case.title}, created_at={case.created_at} already exists, skipping")
                    continue
                
                # Insert into new table
                query = text("""
                INSERT INTO cases (user_id, title, category, status, merit_score, created_at, updated_at) 
                VALUES (:user_id, :title, :category, :status, :merit_score, :created_at, :updated_at)
                """)
                
                connection.execute(query, {
                    'user_id': case.user_id,
                    'title': case.title,
                    'category': case.category,
                    'status': case.status,
                    'merit_score': case.merit_score,
                    'created_at': case.created_at,
                    'updated_at': case.updated_at
                })
                migrated_count += 1
            
            # Commit transaction
            trans.commit()
            logger.info(f"Successfully migrated {migrated_count} cases from 'case' to 'cases'")
            
        except Exception as e:
            trans.rollback()
            logger.error(f"Error migrating cases: {str(e)}")
            raise

def drop_old_tables():
    """Drop old tables after successful migration"""
    with db.engine.connect() as connection:
        trans = connection.begin()
        try:
            # Drop old tables if they exist
            if check_table_exists('user'):
                connection.execute(text('DROP TABLE "user"'))
                logger.info("Dropped old 'user' table")
            
            if check_table_exists('case'):
                connection.execute(text('DROP TABLE "case"'))
                logger.info("Dropped old 'case' table")
                
            # Drop other old tables if needed
            
            # Commit transaction
            trans.commit()
            logger.info("Successfully dropped old tables")
            
        except Exception as e:
            trans.rollback()
            logger.error(f"Error dropping old tables: {str(e)}")
            raise

def run_migration():
    """Run the complete migration process"""
    try:
        logger.info("Starting database migration...")
        
        # Migrate data from old tables to new tables
        migrate_users()
        migrate_cases()
        
        # Ask before dropping old tables
        if input("Do you want to drop old tables? (yes/no): ").lower() == 'yes':
            drop_old_tables()
        
        logger.info("Migration completed successfully")
    except Exception as e:
        logger.error(f"Migration failed: {str(e)}")
        
if __name__ == "__main__":
    with app.app_context():
        run_migration()