"""Gunicorn configuration for handling large file uploads"""

# Timeout for worker processes (seconds) - increased for large file processing
timeout = 600

# Timeout for quiet periods (seconds)
keepalive = 5

# Maximum number of requests a worker will process before restarting
max_requests = 1000

# Maximum number of pending connections
backlog = 2048

# Worker class
worker_class = 'sync'

# Worker connections for handling requests
worker_connections = 1000

# Limit on the size of HTTP request line (in bytes)
limit_request_line = 8190

# Limit on the combined size of all HTTP headers (in bytes) - increased for large file uploads
limit_request_fields_size = 32768

# Maximum size of a request (in bytes) - matches the Flask MAX_CONTENT_LENGTH setting
# 260MB in bytes
limit_request_field_size = 0  # Disable field size limit

# Maximum request body size (in bytes) - 300MB
# This is critical for large file uploads
post_maxbytes = 300 * 1024 * 1024

# Worker options for handling large files
worker_tmp_dir = '/tmp'
threads = 4