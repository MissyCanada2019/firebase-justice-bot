#!/usr/bin/env python3
"""
PostgreSQL Migration Script: Integer IDs to UUIDs

This script migrates existing data from old tables with integer IDs to new tables with UUID primary keys.
It should be used when moving from the original schema to the new UUID-based schema.

WARNING: This is a complex migration and should be tested thoroughly.
"""

import os
import sys
import logging
import uuid
from datetime import datetime
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import text, MetaData

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Create a minimal Flask app for the migration
app = Flask(__name__)

# Configure the database connection
db_url = os.environ.get("DATABASE_URL")
if db_url and db_url.startswith('postgres://'):
    db_url = db_url.replace('postgres://', 'postgresql://')

app.config["SQLALCHEMY_DATABASE_URI"] = db_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize SQLAlchemy
db = SQLAlchemy(app)

def check_table_exists(table_name):
    """Check if a table exists in the database"""
    with db.engine.connect() as connection:
        result = connection.execute(text(
            f"SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = '{table_name}')"
        ))
        return result.scalar()

def get_row_count(table_name):
    """Get the number of rows in a table"""
    with db.engine.connect() as conn:
        return conn.execute(text(f'SELECT COUNT(*) FROM "{table_name}"')).scalar()

def backup_existing_data(backup_suffix="_backup"):
    """Create backup copies of all tables"""
    try:
        with db.engine.connect() as conn:
            conn = conn.execution_options(isolation_level="AUTOCOMMIT")
            
            # Get list of all tables
            inspector = db.inspect(db.engine)
            table_names = inspector.get_table_names()
            
            # Filter out tables that are already backups
            original_tables = [t for t in table_names if not t.endswith(backup_suffix)]
            
            if not original_tables:
                logger.warning("No tables found to backup")
                return
            
            logger.info(f"Creating backups for {len(original_tables)} tables...")
            
            for table_name in original_tables:
                backup_table = f"{table_name}{backup_suffix}"
                
                # Drop backup table if it already exists
                if backup_table in table_names:
                    conn.execute(text(f'DROP TABLE IF EXISTS "{backup_table}" CASCADE'))
                
                # Create backup table
                conn.execute(text(f'CREATE TABLE "{backup_table}" AS SELECT * FROM "{table_name}"'))
                original_count = get_row_count(table_name)
                backup_count = get_row_count(backup_table)
                
                if original_count == backup_count:
                    logger.info(f"Successfully backed up {table_name} ({original_count} rows)")
                else:
                    logger.error(f"Backup verification failed for {table_name}: {original_count} rows vs {backup_count} rows in backup")
                    
            logger.info("Backup completed successfully")
            
    except Exception as e:
        logger.error(f"Error backing up data: {e}")
        raise

def create_new_tables():
    """Create new tables with UUID-based schema"""
    try:
        with app.app_context():
            # Import models when needed to avoid circular imports
            import models
            
            # Create tables in the database
            db.create_all()
            
            logger.info("New tables created successfully")
            
    except Exception as e:
        logger.error(f"Error creating new tables: {e}")
        raise

def migrate_users():
    """Migrate data from old 'users' table to new UUID-based 'users' table"""
    if not check_table_exists('users_backup'):
        logger.warning("users_backup table not found. Run backup_existing_data() first.")
        return
    
    try:
        with db.engine.connect() as conn:
            conn = conn.execution_options(isolation_level="AUTOCOMMIT")
            
            # Create a temporary table with UUIDs associated with old IDs
            conn.execute(text("""
            DROP TABLE IF EXISTS user_id_map;
            CREATE TABLE user_id_map (
                old_id INTEGER PRIMARY KEY,
                new_id UUID NOT NULL DEFAULT gen_random_uuid()
            )
            """))
            
            # Populate the mapping table
            conn.execute(text("""
            INSERT INTO user_id_map (old_id)
            SELECT id FROM users_backup
            """))
            
            # Get column info from the users table to handle schema differences
            result = conn.execute(text("""
            SELECT column_name 
            FROM information_schema.columns 
            WHERE table_name = 'users_backup'
            """))
            columns = [row[0] for row in result.fetchall()]
            
            # Map fields between old and new schemas
            field_map = {
                'id': 'id',
                'username': 'full_name',  # Map username to full_name for demonstration
                'email': 'email',
                'password_hash': 'password_hash',
                'created_at': 'created_at',
                'subscription_type': None,  # Not in new schema
                'subscription_end': None,   # Not in new schema
                'settings': 'settings',
                'uuid': None,               # Not in new schema
                'role': 'role'              # If exists in old schema
            }
            
            # Build SQL field list based on available columns
            target_fields = []
            source_fields = []
            
            for old_field, new_field in field_map.items():
                if old_field in columns and new_field:
                    target_fields.append(new_field)
                    if old_field == 'id':
                        source_fields.append('u.new_id')
                    else:
                        source_fields.append(f'ub.{old_field}')
            
            # Add role if it doesn't exist
            if 'role' in target_fields:
                pass  # Already handled in the mapping
            else:
                target_fields.append('role')
                source_fields.append("'user'")  # Default role
            
            # Add last_login if not in old schema
            if 'last_login' in target_fields:
                pass
            else:
                target_fields.append('last_login')
                source_fields.append('NULL')
            
            # Build and execute the SQL INSERT
            fields_str = ', '.join(target_fields)
            values_str = ', '.join(source_fields)
            
            sql = f"""
            INSERT INTO users ({fields_str})
            SELECT {values_str}
            FROM users_backup ub
            JOIN user_id_map u ON ub.id = u.old_id
            """
            
            conn.execute(text(sql))
            
            # Save the mapping table for other migrations
            logger.info(f"Successfully migrated users data")
            
    except Exception as e:
        logger.error(f"Error migrating users: {e}")
        raise

def migrate_cases_to_disputes():
    """Migrate data from old 'cases' table to new 'disputes' table"""
    if not check_table_exists('cases_backup'):
        logger.warning("cases_backup table not found. Run backup_existing_data() first.")
        return
    
    if not check_table_exists('user_id_map'):
        logger.warning("user_id_map table not found. Run migrate_users() first.")
        return
    
    try:
        with db.engine.connect() as conn:
            conn = conn.execution_options(isolation_level="AUTOCOMMIT")
            
            # Create a temporary table with UUIDs associated with old IDs
            conn.execute(text("""
            DROP TABLE IF EXISTS case_id_map;
            CREATE TABLE case_id_map (
                old_id INTEGER PRIMARY KEY,
                new_id UUID NOT NULL DEFAULT gen_random_uuid()
            )
            """))
            
            # Populate the mapping table
            conn.execute(text("""
            INSERT INTO case_id_map (old_id)
            SELECT id FROM cases_backup
            """))
            
            # Map fields between old and new schemas
            sql = """
            INSERT INTO disputes (id, user_id, case_type, status, title, created_at, updated_at)
            SELECT 
                c.new_id, 
                u.new_id, 
                cb.category, 
                CASE 
                    WHEN cb.status = 'in_progress' THEN 'draft' 
                    ELSE cb.status 
                END,
                cb.title,
                cb.created_at,
                cb.updated_at
            FROM cases_backup cb
            JOIN case_id_map c ON cb.id = c.old_id
            JOIN user_id_map u ON cb.user_id = u.old_id
            """
            
            conn.execute(text(sql))
            
            logger.info(f"Successfully migrated cases to disputes")
            
    except Exception as e:
        logger.error(f"Error migrating cases to disputes: {e}")
        raise

def migrate_documents():
    """Migrate data from old 'documents' table to new UUID-based 'documents' table"""
    if not check_table_exists('documents_backup'):
        logger.warning("documents_backup table not found. Run backup_existing_data() first.")
        return
    
    if not check_table_exists('case_id_map'):
        logger.warning("case_id_map table not found. Run migrate_cases_to_disputes() first.")
        return
    
    try:
        with db.engine.connect() as conn:
            conn = conn.execution_options(isolation_level="AUTOCOMMIT")
            
            # Create a temporary table with UUIDs associated with old IDs
            conn.execute(text("""
            DROP TABLE IF EXISTS document_id_map;
            CREATE TABLE document_id_map (
                old_id INTEGER PRIMARY KEY,
                new_id UUID NOT NULL DEFAULT gen_random_uuid()
            )
            """))
            
            # Populate the mapping table
            conn.execute(text("""
            INSERT INTO document_id_map (old_id)
            SELECT id FROM documents_backup
            """))
            
            # Map fields between old and new schemas
            sql = """
            INSERT INTO documents (id, dispute_id, file_name, file_url, file_type, extracted_text, doc_metadata, created_at)
            SELECT 
                d.new_id, 
                c.new_id,
                db.filename,
                db.file_path,
                db.file_type,
                db.extracted_text,
                db.doc_metadata,
                db.uploaded_at
            FROM documents_backup db
            JOIN document_id_map d ON db.id = d.old_id
            JOIN case_id_map c ON db.case_id = c.old_id
            """
            
            conn.execute(text(sql))
            
            logger.info(f"Successfully migrated documents")
            
    except Exception as e:
        logger.error(f"Error migrating documents: {e}")
        raise

def migrate_merit_scores():
    """Migrate merit scores from cases to case_merit_scores table"""
    if not check_table_exists('cases_backup'):
        logger.warning("cases_backup table not found. Run backup_existing_data() first.")
        return
    
    if not check_table_exists('case_id_map'):
        logger.warning("case_id_map table not found. Run migrate_cases_to_disputes() first.")
        return
    
    try:
        with db.engine.connect() as conn:
            conn = conn.execution_options(isolation_level="AUTOCOMMIT")
            
            # Only migrate cases that have a merit score
            sql = """
            INSERT INTO case_merit_scores (id, dispute_id, score, created_at)
            SELECT 
                gen_random_uuid(),
                c.new_id,
                CAST(cb.merit_score * 100 AS INTEGER),  -- Convert from 0-1 scale to 0-100
                NOW()
            FROM cases_backup cb
            JOIN case_id_map c ON cb.id = c.old_id
            WHERE cb.merit_score IS NOT NULL
            """
            
            conn.execute(text(sql))
            
            logger.info(f"Successfully migrated merit scores")
            
    except Exception as e:
        logger.error(f"Error migrating merit scores: {e}")
        raise

def run_migration():
    """Run the complete migration process"""
    try:
        logger.info("Starting database UUID migration...")
        
        # Confirm before proceeding
        confirm = input("This will modify your database schema. Make sure you have a backup. Continue? (yes/no): ")
        if confirm.lower() != 'yes':
            logger.info("Migration cancelled.")
            return
        
        # Backup existing data first
        backup_existing_data()
        
        # Create new tables
        create_new_tables()
        
        # Migrate data table by table
        migrate_users()
        migrate_cases_to_disputes()
        migrate_documents()
        migrate_merit_scores()
        
        # Migrate other tables if needed...
        
        logger.info("Migration completed successfully")
        
    except Exception as e:
        logger.error(f"Migration failed: {e}")
        logger.error("Your database may be in an inconsistent state. Restore from backup.")

if __name__ == "__main__":
    with app.app_context():
        run_migration()