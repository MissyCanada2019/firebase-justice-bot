import os
import logging
import secrets
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect
from sqlalchemy import text

# Configure logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

# Initialize SQLAlchemy
db = SQLAlchemy(model_class=Base)

# Initialize CSRF protection
csrf = CSRFProtect()

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", secrets.token_hex(16))
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)  # needed for url_for to generate with https

# Configure the database
# Get PostgreSQL connection string from environment variables
db_url = os.environ.get("DATABASE_URL")

# Fix common issue with PostgreSQL URLs from Heroku/some PaaS providers
if db_url and db_url.startswith('postgres://'):
    db_url = db_url.replace('postgres://', 'postgresql://')

app.config["SQLALCHEMY_DATABASE_URI"] = db_url or "sqlite:///smartdispute.db"
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
    "pool_size": 10,
    "max_overflow": 20,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Set up upload folder
app.config["UPLOAD_FOLDER"] = os.path.join(os.getcwd(), "uploads")
# Set a generous file size limit that Gunicorn can handle
app.config["MAX_CONTENT_LENGTH"] = 250 * 1024 * 1024  # 250MB max file size for all content
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

# Initialize the extensions
db.init_app(app)
csrf.init_app(app)

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

def migrate_database(app):
    """
    Safely migrate the database to the latest schema
    This is for handling schema changes without losing data
    """
    try:
        with app.app_context():
            # Import models at runtime to avoid circular imports
            import models
            
            # Get database connection
            connection = db.engine.connect()
            transaction = connection.begin()
            
            try:
                # Get list of existing tables from database
                inspector = db.inspect(db.engine)
                existing_tables = inspector.get_table_names()
                
                # Check if we need to apply migrations
                if len(existing_tables) == 0:
                    # First time setup - create all tables
                    app.logger.info("Creating database tables (first time setup)")
                    db.create_all()
                else:
                    # Update existing tables without losing data
                    app.logger.info("Checking for database migrations")
                    
                    # Check for PostgreSQL-specific issues - old tables with reserved keywords
                    # We need to handle user->users and case->cases migrations
                    old_tables = []
                    for old_name, new_name in [('user', 'users'), ('case', 'cases')]:
                        if old_name in existing_tables and new_name in db.metadata.tables.keys():
                            old_tables.append((old_name, new_name))
                    
                    if old_tables:
                        app.logger.warning(f"Found tables with reserved keywords that need migration: {old_tables}")
                        app.logger.warning("Please run db_migration.py to migrate data and drop old tables")
                    
                    # Create any missing tables
                    for table_name in db.metadata.tables.keys():
                        if table_name not in existing_tables:
                            app.logger.info(f"Creating new table: {table_name}")
                            # Use SQLAlchemy's create_all with specific table - this handles quotes properly
                            try:
                                db.metadata.tables[table_name].create(db.engine)
                            except Exception as e:
                                app.logger.warning(f"Default table creation failed: {e}, trying with quotes")
                                # Try with explicit quoting for reserved keywords
                                create_table_sql = f'CREATE TABLE "{table_name}" ()'
                                db.session.execute(text(create_table_sql))
                                app.logger.info(f"Created empty table '{table_name}' with quotes")
                                # We'll need to add columns one by one
                    
                    # Now handle columns for existing tables
                    for table_name in [t for t in db.metadata.tables.keys() if t in existing_tables]:
                        existing_columns = {c["name"] for c in inspector.get_columns(table_name)}
                        model_columns = {c.name for c in db.metadata.tables[table_name].columns}
                        new_columns = model_columns - existing_columns
                        
                        if new_columns:
                            app.logger.info(f"Adding {len(new_columns)} new columns to {table_name}: {new_columns}")
                        
                        for col_name in new_columns:
                            col = db.metadata.tables[table_name].columns[col_name]
                            app.logger.info(f"Adding new column: {table_name}.{col_name}")
                            
                            # Generate simple ALTER TABLE statement - may fail for complex types
                            try:
                                col_sql = str(col.type).replace('()', '')
                                if col.nullable:
                                    null_text = "NULL"
                                else:
                                    null_text = "NOT NULL"
                                    
                                # Add default value if specified
                                default_text = ""
                                if col.default is not None:
                                    if hasattr(col.default, 'is_scalar') and col.default.is_scalar:
                                        # Only add literal defaults, not computed ones
                                        default_value = col.default.arg
                                        if isinstance(default_value, str):
                                            default_text = f" DEFAULT '{default_value}'"
                                        elif default_value is not None:
                                            default_text = f" DEFAULT {default_value}"
                                
                                # Create ALTER TABLE statement with quoted identifiers to prevent keyword conflicts
                                alter_stmt = f'ALTER TABLE "{table_name}" ADD COLUMN "{col_name}" {col_sql} {null_text}{default_text}'
                                db.session.execute(text(alter_stmt))
                                
                            except Exception as column_err:
                                app.logger.warning(f"Failed to add column {col_name}: {column_err}")
                                app.logger.warning("You may need to manually add this column or run a proper migration")
                    
                    # Create or update indexes
                    for table_name in [t for t in db.metadata.tables.keys() if t in existing_tables]:
                        table = db.metadata.tables[table_name]
                        existing_indexes = {idx['name'] for idx in inspector.get_indexes(table_name)}
                        
                        # Add missing indexes
                        for idx in table.indexes:
                            if idx.name not in existing_indexes:
                                try:
                                    # Special handling for GIN indexes (full-text search)
                                    if hasattr(idx, 'dialect_options') and idx.dialect_options.get('postgresql', {}).get('using') == 'gin':
                                        col_names = ', '.join([f'"{col.name}"' for col in idx.columns])
                                        create_idx_stmt = f'CREATE INDEX "{idx.name}" ON "{table_name}" USING gin ({col_names})'
                                        db.session.execute(text(create_idx_stmt))
                                        app.logger.info(f"Created GIN index: {idx.name} on {table_name}")
                                    else:
                                        # Use SQLAlchemy's create_index
                                        idx.create(db.engine)
                                        app.logger.info(f"Created index: {idx.name} on {table_name}")
                                except Exception as idx_err:
                                    app.logger.warning(f"Failed to create index {idx.name}: {idx_err}")
                
                # Commit the transaction
                transaction.commit()
                app.logger.info("Database migration completed")
                
            except Exception as inner_err:
                # Rollback the transaction if something went wrong
                transaction.rollback()
                app.logger.error(f"Database migration failed - rolling back: {inner_err}")
                raise
                
            finally:
                # Close the connection
                connection.close()
                
    except Exception as e:
        app.logger.error(f"Database migration failed: {e}")
        # Continue without failing completely - we'll use the existing schema
        app.logger.info("Continuing with existing database schema")

with app.app_context():
    # Import models here to register them with SQLAlchemy
    import models  # noqa: F401
    
    # Apply migrations
    migrate_database(app)
    
    # Import and register routes after db initialization
    from routes import init_routes
    init_routes(app)
    
    # Register Google Auth blueprint
    try:
        from google_auth import google_auth
        app.register_blueprint(google_auth)
        app.logger.info("Google OAuth authentication registered successfully")
    except Exception as e:
        app.logger.error(f"Failed to register Google OAuth: {e}")

    # Set up user loader for Flask-Login
    @login_manager.user_loader
    def load_user(user_id):
        from models import User
        return User.query.get(int(user_id))
