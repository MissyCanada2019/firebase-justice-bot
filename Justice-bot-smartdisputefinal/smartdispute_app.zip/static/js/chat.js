/**
 * SmartDispute.ai - AI Chat Interface
 */

document.addEventListener('DOMContentLoaded', function() {
    const chatForm = document.getElementById('chatForm');
    const messageInput = document.getElementById('messageInput');
    const chatMessages = document.getElementById('chatMessages');
    const sessionIdInput = document.getElementById('sessionId');
    
    if (!chatForm || !messageInput || !chatMessages || !sessionIdInput) return;
    
    // Scroll chat to bottom
    scrollChatToBottom();
    
    // Handle form submission
    chatForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const message = messageInput.value.trim();
        const sessionId = sessionIdInput.value;
        
        if (!message) return;
        
        // Display user message
        appendMessage(message, true);
        
        // Clear input
        messageInput.value = '';
        
        // Show loading indicator
        appendLoadingMessage();
        
        // Send message to server
        fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                message: message,
                session_id: sessionId
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Remove loading indicator
            removeLoadingMessage();
            
            // Display AI response
            appendMessage(data.response, false);
            
            // Scroll to bottom
            scrollChatToBottom();
        })
        .catch(error => {
            console.error('Error:', error);
            
            // Remove loading indicator
            removeLoadingMessage();
            
            // Display error message
            appendErrorMessage();
            
            // Scroll to bottom
            scrollChatToBottom();
        });
        
        // Scroll to bottom
        scrollChatToBottom();
    });
    
    // Auto-resize input field
    messageInput.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });
    
    // Handle case selection for context
    const caseSelect = document.getElementById('caseSelect');
    if (caseSelect) {
        caseSelect.addEventListener('change', function() {
            const caseId = this.value;
            if (caseId) {
                window.location.href = `/chat?case_id=${caseId}`;
            } else {
                window.location.href = '/chat';
            }
        });
    }
});

/**
 * Append a message to the chat
 * @param {string} message - Message content
 * @param {boolean} isUser - Whether the message is from the user
 */
function appendMessage(message, isUser) {
    const chatMessages = document.getElementById('chatMessages');
    if (!chatMessages) return;
    
    // Create message element
    const messageDiv = document.createElement('div');
    messageDiv.className = isUser ? 'chat-message user-message' : 'chat-message ai-message';
    
    // Process message text (convert URLs to links, etc.)
    const processedMessage = processMessageText(message);
    
    messageDiv.innerHTML = processedMessage;
    
    // Add to chat container
    chatMessages.appendChild(messageDiv);
    
    // Scroll to bottom
    scrollChatToBottom();
}

/**
 * Process message text for display
 * @param {string} text - Raw message text
 * @return {string} Processed HTML
 */
function processMessageText(text) {
    try {
        // Check if the text is already HTML by looking for common HTML tags
        const containsHTML = /<\/?[a-z][\s\S]*>/i.test(text);
        
        // If it doesn't contain HTML, process it as text
        if (!containsHTML) {
            // Convert URLs to clickable links
            const urlRegex = /(https?:\/\/[^\s]+)/g;
            text = text.replace(urlRegex, url => `<a href="${url}" target="_blank" rel="noopener noreferrer">${url}</a>`);
            
            // Convert markdown-style links [text](url)
            const markdownLinkRegex = /\[([^\]]+)\]\(([^)]+)\)/g;
            text = text.replace(markdownLinkRegex, (match, linkText, url) => 
                `<a href="${url}" target="_blank" rel="noopener noreferrer">${linkText}</a>`
            );
            
            // Handle line breaks
            text = text.replace(/\n/g, '<br>');
        }
        
        return text;
    } catch (error) {
        console.error("Error processing message text:", error);
        return text; // Return original text if there was an error
    }
}

/**
 * Append a loading message
 */
function appendLoadingMessage() {
    const chatMessages = document.getElementById('chatMessages');
    if (!chatMessages) return;
    
    const loadingDiv = document.createElement('div');
    loadingDiv.className = 'chat-message ai-message loading-message';
    loadingDiv.innerHTML = `
        <div class="d-flex align-items-center">
            <div class="spinner-grow spinner-grow-sm me-2" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <div class="spinner-grow spinner-grow-sm me-2" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <div class="spinner-grow spinner-grow-sm" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    `;
    
    chatMessages.appendChild(loadingDiv);
    scrollChatToBottom();
}

/**
 * Remove loading message
 */
function removeLoadingMessage() {
    const loadingMessage = document.querySelector('.loading-message');
    if (loadingMessage) {
        loadingMessage.remove();
    }
}

/**
 * Append an error message
 */
function appendErrorMessage() {
    const chatMessages = document.getElementById('chatMessages');
    if (!chatMessages) return;
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'chat-message ai-message text-danger';
    errorDiv.innerHTML = 'Sorry, I encountered an error processing your request. Please try again.';
    
    chatMessages.appendChild(errorDiv);
}

/**
 * Scroll chat container to the bottom
 */
function scrollChatToBottom() {
    const chatContainer = document.querySelector('.chat-container');
    if (chatContainer) {
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }
}
